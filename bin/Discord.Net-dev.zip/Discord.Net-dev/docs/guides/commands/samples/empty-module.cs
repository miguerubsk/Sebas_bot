using Discord.Commands;

public class InfoModule : ModuleBase<SocketCommandContext>
{
    
}