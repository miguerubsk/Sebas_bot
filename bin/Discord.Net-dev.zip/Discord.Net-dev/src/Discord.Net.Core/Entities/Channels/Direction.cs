﻿namespace Discord
{
    public enum Direction
    {
        Before,
        After,
        Around
    }
}
