namespace Discord
{
    public enum EmbedType
    {
        Unknown = -1,
        Rich,
        Link,
        Video,
        Image,
        Gifv,
        Article,
        Tweet,
        Html,
    }
}
