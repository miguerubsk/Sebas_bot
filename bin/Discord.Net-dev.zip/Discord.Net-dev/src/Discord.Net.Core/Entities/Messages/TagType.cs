﻿namespace Discord
{
    public enum TagType
    {
        UserMention,
        ChannelMention,
        RoleMention,
        EveryoneMention,
        HereMention,
        Emoji
    }
}
