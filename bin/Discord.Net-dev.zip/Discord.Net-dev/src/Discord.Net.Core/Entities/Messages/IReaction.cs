﻿namespace Discord
{
    public interface IReaction
    {
        IEmote Emote { get; }
    }
}
