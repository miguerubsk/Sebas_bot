﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Discord
{
    /// <summary>
    /// Represents data applied to an <see cref="IAuditLogEntry"/>
    /// </summary>
    public interface IAuditLogData
    { }
}
