﻿namespace Discord
{
    public enum LoginState : byte
    {
        LoggedOut,
        LoggingIn,
        LoggedIn,
        LoggingOut
    }
}
