﻿#pragma warning disable CS1591
namespace Discord.API
{
    internal enum RelationshipType
    {
        Friend = 1,
        Blocked = 2,
        IncomingPending = 3,
        OutgoingPending = 4
    }
}
